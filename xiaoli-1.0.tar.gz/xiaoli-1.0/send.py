__all__ = ["sendmsg"]
def sendmsg():
    print("发送短信")
