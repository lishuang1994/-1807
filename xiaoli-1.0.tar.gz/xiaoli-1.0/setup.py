from distutils.core import setup
setup(name = "xiaoli",version="1.0",description="xiaoli's mdule",author="xiaoli",py_modules=["send"])
